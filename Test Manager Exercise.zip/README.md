# home-task-fe

home-task-fe is a automation testing frameework to test the knowledge of automation testing

## Installation

Clone or download the project

```bash
git clone https://github.com/lutr01/home-task-fe.git
```

install the npm (please make sure you have nodejs on your machine)

```bash
npm i
```

## Usage

to run the tests in the headless mode, run

```bash
npm run test
```

to run the tests in the headed mode, run

```bash
npm run test:open
```
